//
//  ContentView.swift
//  Day4_Assignment
//
//  Created by Taibah Valley Academy on 06/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @State private var isBlack: Bool = true
    @State private var textColor: Color = .black
    var body: some View {
        
        ZStack {
            Color.blue.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                ZStack{
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: 100, height: 100)
                        .cornerRadius(20)
                        .shadow(color:.gray ,radius: 2 , x: 1, y: 1)
                    // image representing user profile
                    Image(systemName: "person")
                        .resizable() // make the image resizable
                        .frame(width: 50, height: 50)// change the size
                        .imageScale(.large)
                        .foregroundStyle(Color.white)
                }
                //text label for user name
                Text("Hello, Rayaheen Mseri!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundStyle(textColor)
                Spacer()
                HStack {
                    Text("Press Me:")
                        .foregroundStyle(textColor)
                    //button to change text color
                    Button("change text color!"){
                        if isBlack {
                            textColor = .blue
                        } else {
                            textColor = .black
                        }
                        isBlack.toggle() // toggle the boolean value
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(5)
                }
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
