//
//  Day4_AssignmentApp.swift
//  Day4_Assignment
//
//  Created by Taibah Valley Academy on 06/09/1446 AH.
//

import SwiftUI

@main
struct Day4_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
